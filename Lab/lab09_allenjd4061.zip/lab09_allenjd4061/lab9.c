#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void displayFloat(float f);
float makeFloat(char* f);
int findExponent(char* f);
char* findFraction(char* f);

typedef union floatU{
	unsigned int bits;
	float theFloat;
}floatU;

/*
 *CS252 - Lab 09
 *Author: Jakob Allen (allenjd4061)
 */

int main(){
	displayFloat(-5.8125);
	displayFloat(+0.75);
	displayFloat(-1.5);

	float result = makeFloat("-101.1101");
	printf("%f\n", result);
	displayFloat(result);
}


void displayFloat(float f){
	int i;
	floatU new;
	new.theFloat = f;
	for(i=31; i>=0; i--){
		printf("%d", (new.bits >> i) & 1);
		if(i==31){
			printf(" "); //print space to separate sign bit and exponent
		}else if(i== 23){
			printf(" "); //print space to separate mantissa and exponent
		}
	}
	printf("\n");
}

float makeFloat(char* f){
	floatU new;
	new.bits = 0;
	char* frac = findFraction(f);
	int i;
	for(i=1; i<strlen(frac); i++){
		new.bits = (new.bits << 1) + (frac[i] - '0'); //convert the string into the fraction
	}
	new.bits = (new.bits <<( 23-strlen(frac))); //push the bits to where they belong
	free(frac);
	char exp = findExponent(f); //set exponent to character given it is the right number of bits
	new.bits = new.bits | ( exp <<23); //set the exponent in the float
	if(f[0] == '-'){ new.bits = new.bits | (1<<31);} //set the sign bit
	return new.theFloat;
}

int findExponent(char* f){
	int i;
	i=0;
	while(f[i+1] != '.' && i < strlen(f)){
		i++;
	}
	if(f[0] == '-' || f[0] == '+'){
		i--;
	}
	return i+127; //add the bias
}

char* findFraction(char* f){
	int i;
	if(f[0] == '+' || f[0] == '-'){ i=2;} else{ i=1;} //find the starting point
	int j = 0;
	char* fraction = (char*) malloc(23*sizeof(char));
	while(f[i] != '\0'){
		if(f[i] == '.'){ //ignore the radix
			i++;
		}else{
			fraction[j] = f[i];
			j++;
			i++;
		}
	}
	fraction[j] = '\0';
	return fraction;
}
